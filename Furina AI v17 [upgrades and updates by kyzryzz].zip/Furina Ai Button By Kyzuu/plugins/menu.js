import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import fs from 'fs'
import fetch from 'node-fetch'
const {
    proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia
  } = (await import('@adiwajshing/baileys')).default

let handler = async (m, {
    conn,
    groupMetadata,
    usedPrefix,
    command, 
    args
}) => {
  const cmd = args[0] || 'list';
  let type = (args[0] || '').toLowerCase()
  let _menu = global.db.data.settings[conn.user.jid]
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  const tagCount = {};
  const tagHelpMapping = {};
  Object.keys(global.plugins)
    .filter(plugin => !plugin.disabled)
    .forEach(plugin => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags)
        ? global.plugins[plugin].tags
        : [];

      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];

        tagsArray.forEach(tag => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });
           let isiMenu = []
          let objekk = Object.keys(tagCount)
          Object.entries(tagCount).map(([key, value]) => isiMenu.push({
          header: `Menu ${key}`,
                    title: `📌 Menu ${key}`,
                    description: `Menampilkan cmd ${key}`,
                    id: ".menu " + key,
                    })
          ).join();
          const listAnu = {
    title: "List Menu",
    sections: [{
            title: "📍 Menu all",
            highlight_label: "Tampilkan semua menu",
            rows: [{
                    header: "Menu All",
                    title: "Menampilkan semua tags & cmd",
                    description: "",
                    id: ".menu all",
                }],
        },
        {
            title: '📍 Menu List',
            highlight_label: "List Menu",
            rows: [...isiMenu]
        },
        {
            title: '📍 Information',
            highlight_label: "Informasi Bot",
            rows: [
            {
                    header: "Info Script Bot Ini",
                    title: "",
                    description: "",
                    id: ".sc",
                },
            {
                    header: "Info owner",
                    title: "",
                    description: "",
                    id: ".owner",
                },
            {
                    header: "Info total fitur",
                    title: "",
                    description: "",
                    id: ".totalfitur",
                },
            {
                    header: "Tutorial penggunaan",
                    title: "",
                    description: "",
                    id: ".tutorial",
                },
            {
                    header: "Info rules",
                    title: "",
                    description: "",
                    id: ".rules",
                }
                ]
        }
    ]
};

  let objek = Object.values(db.data.stats).map(v => v.success)
  let totalHit = 0
   for (let b of objek) {
    totalHit += b
    }
  let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
    return {
      help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
      tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
      prefix: 'customPrefix' in plugin,
      limit: plugin.limit,
      premium: plugin.premium,
      enabled: !plugin.disabled,
    }
  });
    
   let data = db.data.users[m.sender];
   let fitur = Object.values(plugins).filter(v => v.help).map(v => v.help).flat(1);
   let tUser = Object.keys(db.data.users).length;
   let userReg = Object.values(global.db.data.users).filter(user => user.registered == true).length
 
  await conn.sendMessage(m.chat, { react: { text: `⏳`, key: m.key }});
    let soun = ["aku-ngakak",
        "anjay",
        "ara-ara2",
        "ara-ara-cowok",
        "ara-ara",
        "arigatou",
        "assalamualaikum",
        "asu",
        "ayank",
        "bacot",
        "bahagia-aku",
        "baka",
        "bansos",
        "beat-box2",
        "beat-box",
        "biasalah",
        "bidadari",
        "bot",
        "buka-pintu",
        "canda-anjing",
        "cepetan",
        "china",
        "cuekin-terus",
        "daisuki-dayo",
        "daisuki",
        "dengan-mu",
        "Donasiku",
        "gaboleh-gitu",
        "gak-lucu",
        "gamau",
        "gay",
        "gelay",
        "gitar",
        "gomenasai",
        "hai-bot",
        "hampa",
        "hayo",
        "hp-iphone",
        "ih-wibu",
        "i-like-you",
        "india",
        "karna-lo-wibu",
        "kiss",
        "kontol",
        "ku-coba",
        "maju-wibu",
        "makasih",
        "mastah",
        "menuasli",
        "menuku",
        "menu",
        "MenuYuki",
        "nande-nande",
        "nani",
        "ngadi-ngadi",
        "nikah",
        "nuina",
        "onichan",
        "ownerku",
        "owner-sange",
        "pak-sapardi",
        "pale",
        "pantek",
        "pasi-pasi",
        "punten",
        "sayang",
        "siapa-sih",
        "sudah-biasa",
        "summertime",
        "tanya-bapak-lu",
        "to-the-bone",
        "wajib",
        "waku",
        "woi",
        "yamete",
        "yowaimo",
        "yoyowaimo"
    ].getRandom()
    let vn = "https://raw.githubusercontent.com/AyGemuy/HAORI-API/main/audio/" + soun + ".mp3"
    let ppl = await( await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/24fa902ead26340f3df2c.png'))
    const text = `*🫧 \`sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ ʙᴏᴛ ғᴜʀɪɴᴀ - ᴀɪ\`*!\n`
    const headers = `> ────────────────\n          ʜᴇʟʟo *@${m.sender.split("@")[0]}*🫰.\n> I ᴀᴍ ғᴜʀɪɴᴀ, ɪ ᴀᴍ ᴀ ᴡʜᴀᴛsᴀᴘᴘ ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ ʙᴏᴛ ᴛʜᴀᴛ ᴡɪʟʟ ʜᴇʟᴘ ᴡɪᴛʜ ᴅᴀɪʟʏ ᴀᴄᴛɪᴠɪᴛɪᴇs ᴠɪᴀ WʜᴀᴛsAᴘᴘ.\n> ʏᴏᴜ ᴄᴀɴ ᴜsᴇ ᴍᴇ ᴛᴏ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏs, ʟɪsᴛᴇɴ ᴛᴏ sᴏɴɢs, ᴄʀᴇᴀᴛᴇ sᴛɪᴄᴋᴇʀs, eᴛc.\n\n> ────────────────`;

if (cmd === 'list') {
    const daftarTag = Object.keys(tagCount)
      .sort()
      .join('\n - ' + usedPrefix + command + '  ');
    const more = String.fromCharCode(8206)
    const readMore = more.repeat(4001)
    let _mpt
    if (process.send) {
      process.send('uptime')
      _mpt = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let mpt = clockString(_mpt)
    let name = m.pushName || conn.getName(m.sender)
    let list = `\n╭────✎「 \`*LIST MENU*\` 」
│ - ${usedPrefix + command} all
│ - ${daftarTag}
╰─────────────────-\n`
 const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/bf29252842366db5ae047.jpg");
    const allTagsAndHelp = Object.keys(tagCount).map(tag => {
      const daftarHelp = tagHelpMapping[tag].map((helpItem, index) => {
        const premiumSign = help[index].premium ? '🅟' : '';
        const limitSign = help[index].limit ? 'Ⓛ' : '';
        return `.${helpItem} ${premiumSign}${limitSign}`;
      }).join('\n│ - ' + ' ');
      return`\n╭────✎「 *${kyzryzz}MENU ${tag.toUpperCase()}${kyzryzz}* 」───✎\n│ - ${daftarHelp}\n╰─────────────────────-\n`;
    }).join('\n');
    let all =  `\n${allTagsAndHelp}\n${wm}`

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
              "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                  text: headers.trim()
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: wm
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ video : { url: 'https://telegra.ph/file/34b7523e6307afea2cba8.mp4'}}, { upload: conn.waUploadToServer})), 
                  title: "",
                  gifPlayback: true,
                  subtitle: 'menu',
                  hasMediaAttachment: false  
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: [{
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listAnu) 
              }],
                }),
                contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363247149539361@newsletter',
                  newsletterName: '🔮 Powered By KyzRyzz',
                  serverMessageId: null
                }
              }
              })
          }
        },
      }, {quoted:m})
      
      await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
        })
        await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});

  } else if (tagCount[cmd]) { 
const daftarHelp = tagHelpMapping[cmd].map((helpItem, index) => {
        
      const premiumSign = help[index].premium ? '🅟' : '';
      const limitSign = help[index].limit ? 'Ⓛ' : '';
      return `.${helpItem} ${premiumSign}${limitSign}`;
    }).join('\n│ - '  + ' ');
        const more = String.fromCharCode(8206)
        const readMore = more.repeat(4001)
        
    const list2 =  `\n╭────✎「 *${kyzryzz}MENU ${cmd.toUpperCase()}${kyzryzz}* 」
│ - ${daftarHelp}
╰─────────────────-

*Total command fitur ${cmd}: ${tagHelpMapping[cmd].length}*`
    const furin = {
    title: ' Menu lainnya',
    sections: [{
        title: "💎 Fᴜʀɪɴᴀ AI Bᴏᴛ MᴜʟᴛɪDᴇᴠɪᴄᴇ | Pᴏᴡᴇʀᴇᴅ Bʏ 𝗞𝘆𝘇𝗥𝘆𝘇𝘇",
        highlight_label: "Recommend ⭐",
        rows: [{
                    header: "📍 Menu all",
                    title: "Tampilkan semua menu",
                    description: "",
                    id: ".menu all",
                }],
        },
        {
            title: '',
            highlight_label: "",
            rows: [...isiMenu]
        }
    ]
};
     let caption = `${list2}`
       let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
              "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                  text: caption, 
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: wm
                }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "",
                        subtitle: "",
                        hasMediaAttachment: false,
                        ...await prepareWAMessageMedia({
                            image: {
                                url: furina
                            }
                        }, {
                            upload: conn.waUploadToServer
                        })

                    }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: [{
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(furin) 
              },
    {
        "name": "cta_url",
        "buttonParamsJson": "{\"display_text\":\"ɪɴғᴏ ʙᴏᴛᴢ ғᴜʀɪɴᴀ - ᴀɪ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\"}"
              }],
                }),
                contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363247149539361@newsletter',
                  newsletterName: '🔮 Powered By KyzRyzz',
                  serverMessageId: null
                }
              }
              })
          }
        },
      }, {quoted:m})

          await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
        })
} else if (cmd === 'all') {
    let name = m.pushName || conn.getName(m.sender)
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/bf29252842366db5ae047.jpg");
              const more = String.fromCharCode(8206)
    const readMore = more.repeat(4001)
          const allTagsAndHelp = Object.keys(tagCount).map(tag => {
      const daftarHelp = tagHelpMapping[tag].map((helpItem, index) => {
        const premiumSign = help[index].premium ? '🅟' : '';
        const limitSign = help[index].limit ? 'Ⓛ' : '';
        return ` .${helpItem} ${premiumSign}${limitSign}`;
      }).join('\n│ -' + ' ');
      return`\n╭────✎「 *${kyzryzz}MENU ${tag.toUpperCase()}${kyzryzz}* 」
│ - ${daftarHelp}
╰──────────────────-`;
    }).join('\n');
    let all =  `\n${allTagsAndHelp}\n`
    let caption = `${all}`
        let msgs = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: caption
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: wm
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "",
                        subtitle: "",
                        hasMediaAttachment: false,
                        ...await prepareWAMessageMedia({
                            image: {
                                url: furina
                            }
                        }, {
                            upload: conn.waUploadToServer
                        })

                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
        "name": "cta_url",
        "buttonParamsJson": "{\"display_text\":\" Dᴏɴᴀᴛɪᴏɴ 💎\",\"url\":\"https://saweria.co/kyzxd\",\"merchant_url\":\"https://saweria.co/kyzxd\"}"
    },
    {
        "name": "cta_url",
        "buttonParamsJson": "{\"display_text\":\"ɪɴғᴏ ʙᴏᴛᴢ ғᴜʀɪɴᴀ - ᴀɪ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\"}"
              }],
                    })
                })
            }
        }
    }, {quoted:m})

    await conn.relayMessage(m.chat, msgs.message, {
        messageId: m.key.id
    })
  } else {
  await conn.reply(m.chat, `Mᴇɴᴜ '${cmd}' ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪᴛᴇᴍᴜᴋᴀɴ. ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ '${command}' ᴀᴛᴀᴜ '${command} all' ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ.`,m);
  }
     await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
}


handler.help = ["menu"]
handler.tags = ["main"]
handler.command = /^(menu)$/i

handler.register = true

export default handler
//----------- FUNCTION -------

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
  let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
  let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [ye, ' *Years 🗓️*\n',  mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}

function ucapan() {
    let waktunya = moment.tz("Asia/Makassar").format("HH");
    return waktunya >= 24 ? "Selamat Begadang 🗿" :
        waktunya >= 18 ? "Selamat malam 🌙" :
        waktunya >= 15 ? "Selamat sore 🌅" :
        waktunya > 10 ? "Selamat siang ☀️" :
        waktunya >= 4 ? "Selamat pagi 🌄" :
        "Selamat Pagi 🗿";
}